{
  import "android.widget.*";
  LinearLayout,
  orientation="vertical",
  layout_width="fill",
  layout_height="fill",
  {
    TextView,
    id="tv",
    text="Hello LuaJ++",
    layout_width="fill",
  },
}